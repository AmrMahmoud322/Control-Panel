<?php $__env->startSection('title'); ?>
    الصفحة الرئيسية
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Slide1 -->

<div style="font-size: 30px;">الموقع متاح للاعمال الادارية فقط </div> 
<?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
    <a href="<?php echo e(url('/admin/panel')); ?>" style="font-size: 30px;">
        الذهاب للوحة التحكم
    </a>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>