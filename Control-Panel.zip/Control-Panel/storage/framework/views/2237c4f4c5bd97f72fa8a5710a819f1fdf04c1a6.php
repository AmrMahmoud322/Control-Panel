
<li <?php if($title == 'قائمة البضائع' || $title == 'إضافة صنف جديد' || $title == 'تعديل صنف'): ?>
    class="active"
    <?php endif; ?>
>
    <a href="#"><i class="fa fa-product-hunt fa-2"></i> <span class="nav-label">البضائع</span><span class="fa arrow"></span></a>
    <ul class="nav nav-second-level collapse">
        <li <?php if( $title == 'قائمة البضائع'): ?>
        class="active"
        <?php endif; ?>
        ><a href="<?php echo e(url('/admin/product/')); ?>"> قائمة البضائع</a></li>
        
        <?php if( Auth::user()->admin == 1): ?>
            <li <?php if( $title == 'إضافة صنف جديد' ): ?>
            class="active"
            <?php endif; ?>
            ><a href="<?php echo e(url('/admin/product/new')); ?>">اضافة صنف جديد</a></li>
        <?php endif; ?>
        
        <?php if($title == 'تعديل صنف'): ?>
            <li class="active"><a href="#">تعديل صنف </a></li>
        <?php endif; ?>
    </ul>
</li>



<li <?php if($title == 'عمل فاتورة' || $title == 'قائمة الفواتير' || $title == 'تعديل فاتورة'): ?>
    class="active"
    <?php endif; ?>
>
    <a href="#"><i class="fa fa-bar-chart-o"></i> <span class="nav-label">الفواتير</span><span class="fa arrow"></span></a>

    <ul class="nav nav-second-level collapse">

        <li <?php if( $title == 'قائمة الفواتير' ): ?>
        class="active"
        <?php endif; ?>
        ><a href="<?php echo e(url('/admin/bill')); ?>">عرض قائمة الفواتير</a></li>
        <li <?php if( $title == 'عمل فاتورة' ): ?>
        class="active"
        <?php endif; ?>
        ><a href="<?php echo e(url('/admin/bill/new')); ?>">عمل فاتورة جديدة</li>
        <?php if( Auth::user()->admin == 1 && $title == 'تعديل فاتورة'): ?>
            <li 
            <?php if( $title == 'تعديل فاتورة' ): ?>
            class="active"
            <?php endif; ?>
            ><a href="">تعديل فاتورة</a></li>
        <?php endif; ?>
        
    </ul>
</li>

<?php if( Auth::user()->admin == 1): ?>

<li <?php if($title == 'إضافة عضو جديد' || $title == 'تعديل اعدادات عضو' || $title == 'قائمة الاعضاء'): ?>
    class="active"
    <?php endif; ?>
>
    <a href="#"><i class="fa fa-users"></i> <span class="nav-label">الاعضاء</span><span class="fa arrow"></span></a>
    <ul class="nav nav-second-level collapse">

        <li <?php if( $title == 'قائمة الاعضاء' ): ?>
        class="active"
        <?php endif; ?>
        ><a href="<?php echo e(url('/admin/user/list')); ?>">عرض قائمة الاعضاء</a></li>

        <li <?php if( $title == 'إضافة عضو جديد' ): ?>
        class="active"
        <?php endif; ?>
        ><a href="<?php echo e(url('/admin/user/new')); ?>">إضافة عضو جديد</a></li>

        <?php if( $title == 'تعديل اعدادات عضو' ): ?>
        <li class="active">
            <a href="<?php echo e(url('/admin/user/edit')); ?>">تعديل اعدادات الاعضاء</a>
        </li>
        <?php endif; ?>
        
    </ul>
</li>
<?php endif; ?>



