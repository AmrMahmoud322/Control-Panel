<?php $__env->startSection('title'); ?>
    الصفحة الرئيسية
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="font-size:50 px">الموقع متاح للاعمال الادارية فقط </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>