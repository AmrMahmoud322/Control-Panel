<?php 
$title= "تعديل اعدادات عضو";    
 ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10 pull-right" style="direction:rtl">
            <h2 style="font-size: 27px">تعديل اعدادات عضو</h2>
            <ol class="breadcrumb" style="font-size: 18px">
                <li>
                    <a href="#">الرئيسية</a>
                </li>
                <li>
                    الاعضاء
                </li>
                <li class="active">
                    <strong> تعديل اعدادات عضو</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class="wrapper wrapper-content animated fadeInRight ecommerce">

        <div class="row">
            <div class="col-lg-12">
                <div class="tabs-container">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#tab-2" style="font-size:20px"> البيانات</a></li>

                        </ul>
                        <div class="tab-content">
                            
                            <div id="tab-2" class="tab-pane active" style="direction: rtl">
                                <div class="panel-body">
                                    <?php echo Form::open(array('action'=>(['AdminController@update',$user->id]), 'method'=>'POST')); ?>

                                                <?php echo e(csrf_field()); ?>

                                        
                                        <fieldset class="form-horizontal" style="font-size:16px">
                                            <div class="form-group">
                                                <div class="col-sm-10">
                                                <input type="text" id="id" name="id" class="form-control" placeholder="..." value="<?php echo e($user->id); ?>" disabled></div>
                                                <label class="col-sm-2 control-label">رقم العضو:</label>
                                            </div>

                                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                <div class="col-sm-10">
                                                <input type="text" id="name" name="name" class="form-control" placeholder="الاسم" value="<?php echo e($user->name); ?>" required autofocus></div>
                                                <label class="col-sm-2 control-label">آسم العضو:</label>
                                                <div class="col-lg-10">
                                                    <?php if($errors->has('name')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>



                                            <div class="form-group">
                                                
                            
                                                <div class="col-lg-10">
                                                    <input class="form-control" id="" type="email" placeholder="" name="" value="<?php echo e($user->email); ?>" required disabled>
                                                    <input type="hidden" id="email" type="email" name="email" value="<?php echo e($user->email); ?>">
                                                    <?php if($errors->has('email')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <label for="email" class="col-lg-2 control-label">البريد الاليكتروني</label>
                                            </div>

                                            <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                
                        
                                                <div class="col-lg-10">
                                                    <input type="password" id="password" placeholder="ادخل كلمة السر" class="form-control" name="password" required>
                                                    <?php if($errors->has('password')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <label for="password" class="col-lg-2 control-label">كلمة السر</label>
                                            </div>



                                            <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            
                                                <div class="col-lg-10">
                                                    <input id="password-confirm" placeholder="ادخل كلمة السر مره اخري" type="password" class="form-control" name="password_confirmation" required>
                                                </div>
                                                <label for="password-confirm" class="col-lg-2 control-label">تأكيد كلمة السر</label>
                                            </div>
                                            
                                            

                                            <div class="form-group">
                                                <div class="col-sm-10">
                                                    <select class="form-control" id="admin" name="admin" >
                                                        <option value="1"
                                                        <?php if($user->admin == 1): ?>
                                                        SELECTED
                                                        <?php endif; ?>
                                                        >1- مدير</option>
                                                        <option value="2"
                                                        <?php if($user->admin == 2): ?>
                                                        SELECTED
                                                        <?php endif; ?>
                                                        >2-  مدير مساعد</option>
                                                        <option value="0"
                                                        <?php if($user->admin == 0): ?>
                                                        SELECTED
                                                        <?php endif; ?>
                                                        >3-  مستخدم</option>
                                                    </select>
                                                </div>
                                                <label class="col-sm-2 control-label">الصلاحيات:</label>
                                            </div>
                                            <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                            <button type="submit" class="btn btn-outline-secondary" style="float: left">تحديث</button>
                                        </fieldset>

                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

    <script>
        $(document).ready(function(){

            $('.summernote').summernote();

            $('.input-group.date').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>