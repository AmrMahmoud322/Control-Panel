<?php 
$title= "عرض تفاصيل صنف";    
 ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10 pull-right" style="direction:rtl">
            <h2 style="font-size: 27px">عرض تفاصيل صنف</h2>
            <ol class="breadcrumb" style="font-size: 18px">
                <li>
                    <a href="#">الرئيسية</a>
                </li>
                <li>
                    البضائع
                </li>
                <li class="active">
                    <strong> عرض تفاصيل صنف</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class="wrapper wrapper-content animated fadeInRight ecommerce">

        <div class="row">
            <div class="col-lg-12">
                <div class="tabs-container">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#tab-2" style="font-size:20px"> البيانات</a></li>

                        </ul>
                        <div class="tab-content">
                            
                            <div id="tab-2" class="tab-pane active" style="direction: rtl">
                                <div class="panel-body">
                                    <?php if($product): ?>
                                         
                                    
                                    <fieldset class="form-horizontal" style="font-size:16px">
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                            <input type="text" id="id" name="id" class="form-control" placeholder="..." value="<?php echo e($product->id); ?>" disabled></div>
                                            <label class="col-sm-2 control-label">رقم الصنف:</label>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                            <input type="text" id="name" name="name" class="form-control" placeholder="الاسم" value="<?php echo e($product->name); ?>" disabled></div>
                                            <label class="col-sm-2 control-label">آسم الصنف:</label>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                            <input type="text" id="buy_price"  name="buy_price" class="form-control" placeholder="0.0"  value="<?php echo e($product->buy_price); ?>" disabled></div>
                                            <label class="col-sm-2 control-label">سعر الشراء:</label>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                            <input type="text" id="wholesale" name="wholesale" class="form-control" placeholder="0.0"  value="<?php echo e($product->wholesale); ?>" disabled></div>
                                            <label class="col-sm-2 control-label">سعر الجملة:</label>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                            <input type="text" id="price" name="price" class="form-control" placeholder="0.0"  value="<?php echo e($product->price); ?>" disabled></div>
                                            <label class="col-sm-2 control-label">سعر البيع:</label>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                                <select class="form-control" id="type" name="type"  value="<?php echo e($product->type); ?>" disabled>
                                                    <option value="إكسسوارات"
                                                    <?php if($product->type == "إكسسوارات"): ?>
                                                    SELECTED
                                                    <?php endif; ?>
                                                    >1- إكسسوارات</option>
                                                    <option value="صرف صحي"
                                                    <?php if($product->type == "صرف صحي"): ?>
                                                    SELECTED
                                                    <?php endif; ?>
                                                    >2- صرف صحي</option>
                                                    <option value="مياه"
                                                    <?php if($product->type == "مياه"): ?>
                                                    SELECTED
                                                    <?php endif; ?>
                                                    >2- مياه </option>
                                                </select>
                                            </div>
                                            <label class="col-sm-2 control-label">نوع الصنف:</label>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                            <input type="text" id="quantity" name="quantity" class="form-control" placeholder="0"  value="<?php echo e($product->quantity); ?>" disabled></div>
                                            <label class="col-sm-2 control-label">الكيمة:</label>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                            <input type="text" id="min_quantity" name="min_quantity" class="form-control" placeholder="0"  value="<?php echo e($product->min_quantity); ?>" disabled></div>
                                            <label class="col-sm-2 control-label">أقل كيمة:</label>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                            <input type="text" id="notes" name="notes" class="form-control" placeholder="اكتب الملاحظة"  value="<?php echo e($product->notes); ?>" disabled></div>
                                            <label class="col-sm-2 control-label">ملاحظات:</label>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                                <select class="form-control" id="availability" name="availability" value="<?php echo e($product->availability); ?>" disabled>
                                                    <option value="متوفر"
                                                    <?php if($product->type == "متوفر"): ?>
                                                    SELECTED
                                                    <?php endif; ?>
                                                    >1- متوفر</option>

                                                    <option value="كمية قليلة"
                                                    <?php if($product->type == "كمية قليلة"): ?>
                                                    SELECTED
                                                    <?php endif; ?>
                                                    >2- كمية قليلة</option>

                                                    <option value="غير متوفر"
                                                    <?php if($product->type == "غير متوفر"): ?>
                                                    SELECTED
                                                    <?php endif; ?>
                                                    >3-غير متوفر</option>

                                                </select>
                                            </div>
                                            <label class="col-sm-2 control-label">حالة الصنف:</label>
                                        </div>

                                        <?php if(Auth::user()->admin == 1): ?>
                                            <form action="<?php echo e(url('/admin/product/'.$product->id.'/edit')); ?>">
                                                <button type="submit" class="btn btn-outline-secondary" style="float: left">تعديل</button>
                                                
                                            </form>
                                        <?php endif; ?>
                                        
                                    </fieldset>
                                    <?php else: ?>
                                        هذا الصنف غير موجود
                                    <?php endif; ?>
                                
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

    <script>
        $(document).ready(function(){

            $('.summernote').summernote();

            $('.input-group.date').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>