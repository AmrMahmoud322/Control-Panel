<!DOCTYPE html>
<html>


<!-- Mirrored from webapplayers.com/inspinia_admin-v2.7.1/ecommerce_product.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 25 Apr 2017 14:29:54 GMT -->
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="<?php echo e(Request::root()); ?>/admin/img/icon.jpg"/>
    <title>
        لوحة التحكم |
        <?php echo $__env->yieldContent('title'); ?>
    </title>

    <?php echo Html::style('/admin/css/bootstrap.min.css'); ?>

    <?php echo Html::style('/admin/font-awesome/css/font-awesome.css'); ?>


    <?php echo Html::style('/admin/css/plugins/summernote/summernote.css'); ?>

    <?php echo Html::style('/admin/css/plugins/summernote/summernote-bs3.css'); ?>


    <?php echo Html::style('/admin/css/plugins/datapicker/datepicker3.css'); ?>


    <?php echo Html::style('/admin/css/animate.css'); ?>

    <?php echo Html::style('/admin/css/style.css'); ?>


    <?php echo $__env->yieldContent('header'); ?>

</head>

<body>

<div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu" style="direction: rtl; margin-right: -40px">
                <li class="nav-header">
                    <div class="dropdown profile-element"> <span>
                    <img alt="image" class="img-circle" src="<?php echo e(Request::root()); ?>/admin/img/profile_small.jpg" />
                             </span>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <span class="text-muted text-xs block"><strong class="font-bold"><?php echo e(Auth::user()->name); ?></strong> <b class="caret"></b></span> </span> </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a href="profile.html">تعديل الصفحة الشخصية</a></li>
                            <li class="divider"></li>
                            <li>
                                
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">
                                            تسجيل خروج
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                  
                            </li>
                        </ul>
                    </div>
                </li>
                
                <?php echo $__env->make('admin/layouts/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>                
                
            </ul>

        </div>
    </nav>

    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                <ul class="nav navbar-top-links navbar-right">
                    <li>
                        <span class="m-r-sm text-muted welcome-message" style="font-size: 23px">مرحبا بك في لوحة التحكم</span>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                            <i class="fa fa-sign-out"></i> تسجيل الخروج
                        </a>
                    </li>
                </ul>

            </nav>
        </div>

        <?php echo $__env->make('admin/layouts/messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>


        
        
        
        <div class="footer">
            <div class="pull-right">
                10GB of <strong>250GB</strong> Free.
            </div>
            <div>
                <strong>Copyright</strong> Example Company &copy; 2014-2017
            </div>
        </div>

    </div>
</div>

        <!-- Mainly scripts -->
<?php echo Html::script('/admin/js/jquery-3.1.1.min.js'); ?>

<?php echo Html::script('/admin/js/bootstrap.min.js'); ?>

<?php echo Html::script('/admin/js/plugins/metisMenu/jquery.metisMenu.js'); ?>

<?php echo Html::script('/admin/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>


<!-- Custom and plugin javascript -->
<?php echo Html::script('/admin/js/plugins/pace/pace.min.js'); ?>


<!-- SUMMERNOTE -->
<?php echo Html::script('/admin/js/plugins/summernote/summernote.min.js'); ?>


<!-- Data picker -->
<?php echo Html::script('/admin/js/plugins/datapicker/bootstrap-datepicker.js'); ?>


<?php echo Html::script('/admin/js/inspinia.js'); ?>



<?php echo $__env->yieldContent('footer'); ?>


</body>


</html>
