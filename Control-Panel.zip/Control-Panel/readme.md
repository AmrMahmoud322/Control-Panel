to Run Shopping Cart Project on localhost: <br><br>

<ul>1- Download Shopping Cart ZIP file 'shopping-cart.zip'. </ul>
<ul>2- open termenal from project folder.</ul>
<ul>3- Check whether everything has been installed correctly (git , node , npm and composer).</ul>
<ul>4- Run Mysql on your PC.</ul>
<ul>5- Create a database called "control-panal".</ul>
<ul>6- Change the .env file settings to fit your database settings (such as DB_PORT).</ul>
<ul>
	7- Run commands:<br>
	 <li>	 $ composer install</li>
	 <li>	 $ npm install</li>
	 <li>	 $ npm install --no-bin-links</li>
	 <li>	 $ php artisan migrate</li>
	 <li>	 $ php artisan db:seed</li>
	 <li>	 $ php artisan serve</li>
</ul>
<ul>8- Now you can go to your browser and open project link (Project like such as http://localhost:8000).</ul>



