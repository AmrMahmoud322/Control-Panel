<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bill_products extends Model
{
    //
}
