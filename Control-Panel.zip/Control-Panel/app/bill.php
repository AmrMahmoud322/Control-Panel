<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bill extends Model
{
    // protected $fillable = [
    //     'customer', 'status', 'totalBefore','total', 'discount', 'owner'
    // ];
}
